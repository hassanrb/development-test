<?php defined('ABSPATH') or die('restricted access');
die("Only a static page Home is available in test project"); ?>
