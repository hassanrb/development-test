<?php defined('ABSPATH') or die('restricted access');
die("Only Home Page is available in test project"); ?>
